﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SportLab.Pages
{
    /// <summary>
    /// Логика взаимодействия для AuthPage.xaml
    /// </summary>
    public partial class AuthPage : Page
    {
        public AuthPage()
        {
            InitializeComponent();
        }
        // Вход для Гостя
        private void BtnGuest_Click(object sender, RoutedEventArgs e)
        {
            App.CurrentUser = null; // Зануляем пользователя
                                    // ПЕРЕХОД:
            NavigationService.Navigate(new ProductListPage());
        }

        // Вход для Пользователя с проверкой в БД
        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string login = txtLogin.Text;
            string password = psbPassword.Password;

            // Валидация пустых полей
            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Введите логин и пароль!");
                return;
            }

            try
            {
                // Поиск пользователя в БД
                // Используем App.context, который вы создали
                var userObj = App.context.User.FirstOrDefault(u => u.Login == login && u.Password == password);

                if (userObj != null)
                {
                    App.CurrentUser = userObj;

                    // Добавляем простое свойство роли (строкой)
                    App.CurrentRole = userObj.Role?.Name ?? "Гость";   // если Role null → Гость

                    NavigationService.Navigate(new ProductListPage());
                }
                else
                {
                    MessageBox.Show("Ошибка!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка подключения к базе данных: " + ex.Message);
            }
        }
    }
}

﻿using SportLab.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;



namespace SportLab.Pages
{
    /// <summary>
    /// Логика взаимодействия для ProductListPage.xaml
    /// </summary>

    public partial class ProductListPage : Page
    {
        private List<Product> allProducts;
        private CollectionViewSource viewSource;
        public Visibility EditButtonsVisible { get; set; } = Visibility.Collapsed;

        public ProductListPage()
        {
            InitializeComponent();

            // Загрузка всех данных
            allProducts = App.context.Product.ToList();
            viewSource = new CollectionViewSource { Source = allProducts };
            LViewProducts.ItemsSource = viewSource.View;

            // Подписываемся на событие Filter один раз
            viewSource.Filter += ViewSource_Filter;

            // Заполняем комбобокс поставщиков
            var suppliers = App.context.Postavshik.ToList();
            suppliers.Insert(0, new Postavshik { PostavshikID = -1, Name = "Все поставщики" });
            CmbSupplier.ItemsSource = suppliers;
            CmbSupplier.SelectedIndex = 0;

            // Явно устанавливаем сортировку «без сортировки» по умолчанию
            CmbSort.SelectedIndex = 0;

            RefreshList();  // Начальное обновление

            // Управление видимостью элементов в зависимости от роли (только при первом создании)
            UpdateRoleVisibility();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            // Обновление прав доступа при каждом заходе
            UpdateRoleVisibility();

            // ОБНОВЛЕНИЕ ДАННЫХ И СБРОС ФИЛЬТРОВ
            allProducts = App.context.Product.ToList();
            viewSource.Source = allProducts;

            // Сброс фильтров/поиска/сортировки — чтобы всегда показывались ВСЕ товары
            TxtSearch.Text = string.Empty;
            CmbSupplier.SelectedIndex = 0;
            CmbSort.SelectedIndex = 0;

            RefreshList(); // Применяем (теперь список полный и свежий)
        }

        // Выносим проверку роли в отдельный метод
        private void UpdateRoleVisibility()
        {
            string role = App.CurrentRole?.Trim() ?? "Гость";

            bool isAdmin = role.Equals("Администратор", StringComparison.OrdinalIgnoreCase);
            bool isManager = role.Equals("Менеджер", StringComparison.OrdinalIgnoreCase);

            if (isManager || isAdmin)
            {
                PanelControls.Visibility = Visibility.Visible;

                BtnAdd.Visibility = isAdmin ? Visibility.Visible : Visibility.Collapsed;
                BtnOrders.Visibility = Visibility.Visible;

                // Показываем/скрываем кнопки Редактировать+Удалить в каждой строке
                Visibility editVis = isAdmin ? Visibility.Visible : Visibility.Collapsed;

                foreach (var item in LViewProducts.Items)
                {
                    var container = LViewProducts.ItemContainerGenerator.ContainerFromItem(item) as ListViewItem;
                    if (container == null) continue;

                    var panel = container.Template.FindName("EditButtonsPanel", container) as StackPanel;
                    if (panel != null)
                    {
                        panel.Visibility = editVis;
                    }
                }
            }
            else
            {
                PanelControls.Visibility = Visibility.Collapsed;
            }
            EditButtonsVisible = isAdmin ? Visibility.Visible : Visibility.Collapsed;
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e) => RefreshList();
        private void Cmb_SelectionChanged(object sender, SelectionChangedEventArgs e) => RefreshList();

        private void ViewSource_Filter(object sender, FilterEventArgs e)
        {
            Product p = e.Item as Product;
            if (p == null)
            {
                e.Accepted = false;
                return;
            }

            // Поиск
            if (!string.IsNullOrWhiteSpace(TxtSearch.Text))
            {
                string search = TxtSearch.Text.ToLower();
                if (!p.Name.ToLower().Contains(search) &&
                    !p.Opisanie.ToLower().Contains(search) &&
                    !(p.Proizvoditel?.Name?.ToLower().Contains(search) ?? false) &&
                    !(p.Postavshik?.Name?.ToLower().Contains(search) ?? false) &&
                    !(p.Category?.Name?.ToLower().Contains(search) ?? false))
                {
                    e.Accepted = false;
                    return;
                }
            }

            // Фильтр по поставщику
            if (CmbSupplier.SelectedIndex > 0)
            {
                var selected = CmbSupplier.SelectedItem as Postavshik;
                if (selected != null && p.PostavshikID != selected.PostavshikID)
                {
                    e.Accepted = false;
                    return;
                }
            }

            e.Accepted = true;
        }

        private void RefreshList()
        {
            viewSource.SortDescriptions.Clear();

            if (CmbSort.SelectedIndex == 1) // По цене ↑
                viewSource.SortDescriptions.Add(new SortDescription("Coast", ListSortDirection.Ascending));
            else if (CmbSort.SelectedIndex == 2) // По цене ↓
                viewSource.SortDescriptions.Add(new SortDescription("Coast", ListSortDirection.Descending));

            viewSource.View.Refresh();
            LViewProducts.ItemsSource = null;  // Принудительно "отвязываем"
            LViewProducts.ItemsSource = viewSource.View;  // Привязываем заново

            TxtCount.Text = $"Найдено товаров: {viewSource.View.Cast<object>().Count()}";
            UpdateRoleVisibility();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new EditProductPage(null));
        }
        // Метод для кнопки "Редактировать" внутри строки
        private void BtnEditInList_Click(object sender, RoutedEventArgs e)
        {
            var product = (sender as Button).Tag as Product;
            if (product != null)
            {
                NavigationService.Navigate(new EditProductPage(product));
            }
        }

        // Метод для кнопки "Удалить" внутри строки
        private void BtnDeleteInList_Click(object sender, RoutedEventArgs e)
        {
            var product = (sender as Button).Tag as Product;
            if (product == null) return;

            // Используем вашу логику проверки заказов
            bool inOrder = App.context.OrderDetails.Any(od => od.ProductID == product.ProductID);
            if (inOrder)
            {
                MessageBox.Show("Нельзя удалить товар, который есть в заказах!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (MessageBox.Show($"Вы точно хотите удалить «{product.Name}»?", "Подтверждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                App.context.Product.Remove(product);
                App.context.SaveChanges();
                allProducts.Remove(product);
                RefreshList();
            }
        }

        private void LViewProducts_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            string role = App.CurrentRole?.Trim() ?? "Гость";

            if (LViewProducts.SelectedItem is Product prod &&
                role.Equals("Администратор", StringComparison.OrdinalIgnoreCase))
            {
                NavigationService.Navigate(new EditProductPage(prod));
            }
        }


        private void BtnOrders_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new OrdersListPage());
        }
    }

    public class ProductConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var p = value as Product;
            if (p == null) return null;

            if (parameter.ToString() == "Color")
            {
                if (p.KolvoOnSklad == 0) return Brushes.LightBlue;
                if (p.PresentDiscout > 15) return (SolidColorBrush)new BrushConverter().ConvertFrom("#2E8B57");
                return Brushes.White;
            }

            if (parameter.ToString() == "Price")
            {
                decimal res = p.Coast - (p.Coast * (decimal)p.PresentDiscout / 100);
                return res.ToString("N2");
            }

            if (parameter.ToString() == "Vis")
            {
                return p.PresentDiscout > 0 ? Visibility.Visible : Visibility.Collapsed;
            }

            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => null;
    }

}

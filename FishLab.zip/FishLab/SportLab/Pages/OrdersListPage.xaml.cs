﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SportLab.Entities;

namespace SportLab.Pages
{
    /// <summary>
    /// Логика взаимодействия для OrdersListPage.xaml
    /// </summary>
    public partial class OrdersListPage : Page
    {
        public OrdersListPage()
        {
            InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            RefreshOrders();

            // Видимость кнопок только админу
            if (App.CurrentRole == "Администратор")
            {
                BtnAdd.Visibility = Visibility.Visible;
                BtnDelete.Visibility = Visibility.Visible;
            }
            else
            {
                BtnAdd.Visibility = Visibility.Collapsed;
                BtnDelete.Visibility = Visibility.Collapsed;
            }
        }

        private void RefreshOrders()
        {
            var orders = App.context.Order
                .Include("PickupPoint")
                .Include("Status")
                .Include("User")
                .Include("OrderDetails.Product")
                .ToList();

            LvOrders.ItemsSource = orders;
            TxtCount.Text = $"Найдено заказов: {orders.Count}";
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new EditOrderPage(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (LvOrders.SelectedItems.Count == 0)
            {
                MessageBox.Show("Выберите заказы для удаления!");
                return;
            }

            if (MessageBox.Show("Удалить выбранные заказы?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                var selected = LvOrders.SelectedItems.Cast<Entities.Order>().ToList();
                foreach (var order in selected)
                {
                    // Удаляем детали вручную (на всякий случай)
                    var details = App.context.OrderDetails.Where(d => d.OrderID == order.OrderID).ToList();
                    App.context.OrderDetails.RemoveRange(details);

                    App.context.Order.Remove(order);
                }

                try
                {
                    App.context.SaveChanges();
                    MessageBox.Show("Заказы удалены!");
                    RefreshOrders();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка удаления: " + ex.Message);
                }
            }
        }
    }

    // Конвертер для отображения товаров в заказе (встроен в страницу)
    public class OrderDetailsConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            var details = value as IEnumerable<Entities.OrderDetails>;
            if (details == null || !details.Any()) return "Нет товаров";

            return string.Join("\n", details.Select(d => $"{d.Product.Articul} x {d.KolVo}"));
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}

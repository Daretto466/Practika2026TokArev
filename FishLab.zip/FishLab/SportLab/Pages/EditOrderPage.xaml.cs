﻿using SportLab.Entities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Entity;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.Entity.Infrastructure;

namespace SportLab.Pages
{
    /// <summary>
    /// Логика взаимодействия для EditOrderPage.xaml
    /// </summary>
    public partial class EditOrderPage : Page
    {
        private Entities.Order currentOrder;
        private ObservableCollection<Entities.OrderDetails> orderDetails = new ObservableCollection<Entities.OrderDetails>();

        public EditOrderPage(Entities.Order order)
        {
            InitializeComponent();

            // Пункты выдачи
            CmbPickupPoint.ItemsSource = App.context.PickupPoint.ToList();

            // Статусы
            CmbStatus.ItemsSource = App.context.Status.ToList();

            // Клиенты (уже пофикшенная версия из прошлого ответа)
            var users = App.context.User.ToList();
            var clients = users.Select(u => new
            {
                u.UserID,
                FIO = $"{u.Familiya} {u.Name} {(!string.IsNullOrEmpty(u.Otchestvo) ? u.Otchestvo : "")}".Trim()
            }).ToList();
            CmbClient.ItemsSource = clients;
            CmbClient.DisplayMemberPath = "FIO";  // Здесь DisplayMemberPath работает нормально
            CmbClient.SelectedValuePath = "UserID";

            // Товары для добавления
            CmbAddProduct.ItemsSource = App.context.Product.ToList();
            // Убрали DisplayMemberPath — шаблон в XAML покажет Наименование + Артикул

            DgDetails.ItemsSource = orderDetails;

            currentOrder = order ?? new Entities.Order { DataOrder = DateTime.Today };

            if (order != null)
            {
                // Редактирование
                DpDateOrder.SelectedDate = order.DataOrder;
                DpDateDelivery.SelectedDate = order.DataDelivery;
                CmbPickupPoint.SelectedValue = order.PickupPointID;
                CmbStatus.SelectedValue = order.StatusID;
                CmbClient.SelectedValue = order.ClientID;
                TxtKodPickup.Text = order.KodPickup.ToString();

                // Загружаем существующие детали
                var details = App.context.OrderDetails
                    .Where(d => d.OrderID == order.OrderID)
                    .Include("Product")
                    .ToList();
                foreach (var d in details)
                    orderDetails.Add(d);
            }
            else
            {
                // Новый заказ — генерируем случайный код pickup
                Random rnd = new Random();
                int newKod = rnd.Next(100000, 999999);

                // Сразу пишем и в интерфейс, и в объект
                TxtKodPickup.Text = newKod.ToString();
                currentOrder.KodPickup = newKod;

                // На всякий случай фиксируем сегодняшнюю дату
                currentOrder.DataOrder = DateTime.Today;
                DpDateOrder.SelectedDate = DateTime.Today;
            }
        }

        private void BtnAddDetail_Click(object sender, RoutedEventArgs e)
        {
            if (CmbAddProduct.SelectedItem == null)
            {
                MessageBox.Show("Выберите товар!");
                return;
            }

            if (!int.TryParse(TxtAddKolvo.Text, out int kol) || kol <= 0)
            {
                MessageBox.Show("Введите корректное количество!");
                return;
            }

            var product = (Entities.Product)CmbAddProduct.SelectedItem;

            if (product.KolvoOnSklad < kol)
            {
                MessageBox.Show($"На складе только {product.KolvoOnSklad} шт.!");
                return;
            }

            var detail = new Entities.OrderDetails
            {
                ProductID = product.ProductID,
                Product = product,
                KolVo = kol
            };

            orderDetails.Add(detail);
            TxtAddKolvo.Text = "";
            CmbAddProduct.SelectedIndex = -1;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            // Валидация
            if (DpDateOrder.SelectedDate == null || CmbPickupPoint.SelectedItem == null ||
                CmbStatus.SelectedItem == null || CmbClient.SelectedItem == null ||
                string.IsNullOrWhiteSpace(TxtKodPickup.Text) || orderDetails.Count == 0)
            {
                MessageBox.Show("Заполните все обязательные поля и добавьте хотя бы один товар!");
                return;
            }

            if (!int.TryParse(TxtKodPickup.Text, out int kod) || kod < 100000 || kod > 999999)
            {
                MessageBox.Show("Код pickup должен быть 6-значным числом!");
                return;
            }


            try
            {
                // 1. Простая валидация
                if (CmbPickupPoint.SelectedItem == null || CmbStatus.SelectedItem == null)
                {
                    MessageBox.Show("Заполните обязательные поля!");
                    return;
                }

                // 2. Сбор данных из интерфейса
                currentOrder.DataOrder = DpDateOrder.SelectedDate ?? DateTime.Today;
                currentOrder.DataDelivery = DpDateDelivery.SelectedDate.Value;
                currentOrder.PickupPointID = ((Entities.PickupPoint)CmbPickupPoint.SelectedItem).PickupPointID;
                currentOrder.StatusID = ((Entities.Status)CmbStatus.SelectedItem).StatusID;
                currentOrder.ClientID = (int)CmbClient.SelectedValue;

                // Берем код из текстбокса (на случай если его правили)
                if (int.TryParse(TxtKodPickup.Text, out int res))
                    currentOrder.KodPickup = res;

                // 3. Сохраняем сам заказ (шапку)
                if (currentOrder.OrderID == 0)
                    App.context.Order.Add(currentOrder);

                App.context.SaveChanges(); // Тут получаем OrderID от базы

                // 4. Обновляем товары (состав заказа)
                // Удаляем старые, если это редактирование
                var oldDetails = App.context.OrderDetails.Where(od => od.OrderID == currentOrder.OrderID).ToList();
                App.context.OrderDetails.RemoveRange(oldDetails);

                // Привязываем и добавляем новые
                foreach (var item in orderDetails)
                {
                    item.OrderID = currentOrder.OrderID; // Теперь ID точно есть
                    App.context.OrderDetails.Add(item);
                }

                // 5. Финальное сохранение
                App.context.SaveChanges();

                MessageBox.Show("Заказ успешно сохранен!");
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                // Делаем catch информативным
                string message = ex.Message;
                if (ex.InnerException != null)
                    message += "\nПодробности: " + ex.InnerException.Message;

                MessageBox.Show("Ошибка при сохранении: " + message);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
        private void BtnRemoveDetail_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.DataContext is Entities.OrderDetails detail)
            {
                orderDetails.Remove(detail);
            }
        }
    }
    public class NotZeroToTrueConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is int id)
            {
                return id != 0;  // True if OrderID != 0 (read-only)
            }
            return false;  // Default: editable
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}

﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace SportLab.Pages
{
    /// <summary>
    /// Логика взаимодействия для EditProductPage.xaml
    /// </summary>
    public partial class EditProductPage : Page
    {
        private Entities.Product currentProduct;
        private string oldPhotoPath = null;

        public EditProductPage(Entities.Product product)
        {
            InitializeComponent();

            // Заполняем справочники
            CmbCategory.ItemsSource = App.context.Category.ToList();
            CmbProizvoditel.ItemsSource = App.context.Proizvoditel.ToList();
            CmbPostavshik.ItemsSource = App.context.Postavshik.ToList();

            currentProduct = product ?? new Entities.Product();

            if (product != null)
            {
                // Редактирование
                TxtName.Text = product.Name;
                TxtArticul.Text = product?.Articul ?? "";
                TxtOpisanie.Text = product.Opisanie;
                TxtCoast.Text = product.Coast.ToString();
                TxtUnit.Text = product.Unit;
                TxtKolvo.Text = product.KolvoOnSklad.ToString();
                TxtDiscount.Text = product.PresentDiscout.ToString();
                CmbCategory.SelectedItem = product.Category;
                CmbProizvoditel.SelectedItem = product.Proizvoditel;
                CmbPostavshik.SelectedItem = product.Postavshik;

                if (!string.IsNullOrEmpty(product.Photo))
                    ImgPhoto.Source = new BitmapImage(new Uri(product.Photo, UriKind.RelativeOrAbsolute));

                oldPhotoPath = product.Photo;
            }
            
        }

        private void BtnChoosePhoto_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "Изображения|*.jpg;*.jpeg;*.png";
            if (dlg.ShowDialog() == true)
            {
                // Копируем и ресайзим до 300×200
                BitmapImage src = new BitmapImage(new Uri(dlg.FileName));
                // Простой ресайз
                var resized = new TransformedBitmap(src, new ScaleTransform(300 / src.PixelWidth, 200 / src.PixelHeight));

                string folder = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Images");
                Directory.CreateDirectory(folder);

                string fileName = Guid.NewGuid() + System.IO.Path.GetExtension(dlg.FileName);
                string newPath = System.IO.Path.Combine(folder, fileName);

                JpegBitmapEncoder encoder = new JpegBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(resized));
                using (FileStream fs = File.OpenWrite(newPath))
                    encoder.Save(fs);

                ImgPhoto.Source = new BitmapImage(new Uri(newPath));
                currentProduct.Photo = newPath;
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            // Проверка обязательных полей
            if (string.IsNullOrWhiteSpace(TxtName.Text))
            {
                MessageBox.Show("Введите наименование товара.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(TxtArticul.Text))
            {
                MessageBox.Show("Введите артикул товара (обязательное поле).", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (CmbCategory.SelectedItem == null)
            {
                MessageBox.Show("Выберите категорию товара.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (CmbProizvoditel.SelectedItem == null)
            {
                MessageBox.Show("Выберите производителя.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (CmbPostavshik.SelectedItem == null)
            {
                MessageBox.Show("Выберите поставщика.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(TxtUnit.Text))
            {
                MessageBox.Show("Введите единицу измерения.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Проверка цены
            if (!decimal.TryParse(TxtCoast.Text, out decimal coast) || coast < 0)
            {
                MessageBox.Show("Цена должна быть положительным числом.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Проверка количества
            if (!int.TryParse(TxtKolvo.Text, out int kolvo) || kolvo < 0)
            {
                MessageBox.Show("Количество на складе не может быть отрицательным.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Проверка скидки (может быть пустой → 0)
            byte discount = 0;
            if (!string.IsNullOrWhiteSpace(TxtDiscount.Text))
            {
                if (!byte.TryParse(TxtDiscount.Text, out discount))
                {
                    MessageBox.Show("Скидка должна быть целым числом от 0 до 255.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
            }

            try
            {
                // Заполняем сущность
                currentProduct.Name = TxtName.Text.Trim();
                currentProduct.Articul = TxtArticul.Text.Trim();
                currentProduct.Opisanie = TxtOpisanie.Text;
                currentProduct.Coast = coast;
                currentProduct.Unit = TxtUnit.Text.Trim();
                currentProduct.KolvoOnSklad = kolvo;
                currentProduct.PresentDiscout = discount;

                // Внешние ключи (обязательно!)
                currentProduct.Category = (Entities.Category)CmbCategory.SelectedItem;
                currentProduct.Proizvoditel = (Entities.Proizvoditel)CmbProizvoditel.SelectedItem;
                currentProduct.Postavshik = (Entities.Postavshik)CmbPostavshik.SelectedItem;

                // Если добавление нового товара
                if (currentProduct.ProductID == 0)
                {
                    App.context.Product.Add(currentProduct);
                }

                App.context.SaveChanges();

                // Удаляем старое фото, если заменили
                if (!string.IsNullOrEmpty(oldPhotoPath) &&
                    oldPhotoPath != currentProduct.Photo &&
                    File.Exists(oldPhotoPath))
                {
                    File.Delete(oldPhotoPath);
                }

                MessageBox.Show("Товар успешно сохранён!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                // Возврат на список (он обновится автоматически при переходе назад)
                NavigationService.GoBack();
            }
            catch (DbEntityValidationException dbEx)
            {
                // Детальный вывод ошибок валидации (для дебага — потом можно закомментировать)
                string errors = "";
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        errors += $"{validationError.PropertyName}: {validationError.ErrorMessage}\n";
                    }
                }
                MessageBox.Show("Ошибка валидации:\n" + errors, "Ошибка сохранения", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e) => NavigationService.GoBack();
    }
}

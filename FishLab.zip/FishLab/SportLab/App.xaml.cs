﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace SportLab
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static Entities.FishingEntities context
        { get; } = new Entities.FishingEntities();

        // НОВОЕ: Свойство для хранения авторизованного пользователя
        // Если null - значит это Гость
        public static Entities.User CurrentUser { get; set; } = null;
        public static string CurrentRole { get; set; } = "Гость";   // новое
    }
}
